/**
 * Svelte stores para política seleccionada
 * Resultados (trace/fin) y costos en UI
 */
