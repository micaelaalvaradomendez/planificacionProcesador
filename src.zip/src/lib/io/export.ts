/**
 * Exportación de trazas/métricas (JSON/CSV)
 * Helpers para descarga/serialización
 */
