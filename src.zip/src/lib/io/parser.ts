/**
 * Validación y normalización de entrada (JSON/CSV)
 * Conversión a estructuras de Proceso
 */
