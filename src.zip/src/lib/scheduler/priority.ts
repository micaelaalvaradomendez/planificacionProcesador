/**
 * Planificador por prioridades
 * (Opcional) Envejecimiento/ajuste de prioridad
 */
