/**
 * Planificador SPN (no expropiativo)
 * Selección por ráfaga más corta siguiente
 */
