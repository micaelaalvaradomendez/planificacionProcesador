/**
 * Planificador SRTN (expropiativo)
 * Selección por menor tiempo restante
 */
