/**
 * Tipos para el modelo de Gantt de UI
 * Items, inicio/fin y normalizaciones
 */
