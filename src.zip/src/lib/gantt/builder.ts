/**
 * Conversión de trace.slices a modelo de Gantt
 * Agrupación y orden cronológico para pintar
 */
