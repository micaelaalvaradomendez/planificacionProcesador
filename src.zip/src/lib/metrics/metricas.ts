/**
 * Cálculo de métricas por proceso y globales
 * TRp, TE, TRn, promedios y agregados
 */
